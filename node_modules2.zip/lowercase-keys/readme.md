# lowercase-keys [![Build Status](https://travis-ci.org/sindresorhus/lowercase-keys.svg?branch=master)](https://travis-ci.org/sindresorhus/lowercase-keys)

> Lowercase the keys of an object


## Install

```
$ npm install lowercase-keys
```


## Usage

```js
const lowercaseKeys = require('lowercase-keys');

lowercaseKeys({FOO: true, bAr: false});
//=> {foo: true, bar: false}
```


## API

### lowercaseKeys(object)

Returns a new object with the keys lowercased.


## License

MIT © [Sindre Sorhus](https://sindresorhus.com)
