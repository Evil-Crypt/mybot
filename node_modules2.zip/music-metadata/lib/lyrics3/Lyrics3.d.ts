import { IRandomReader } from '../type';
export declare const endTag2 = "LYRICS200";
export declare function getLyricsHeaderLength(reader: IRandomReader): Promise<number>;
