# Installation
> `npm install --save @types/keyv`

# Summary
This package contains type definitions for keyv (https://github.com/lukechilds/keyv).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/keyv.

### Additional Details
 * Last updated: Thu, 17 Mar 2022 05:31:42 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [AryloYeung](https://github.com/Arylo), and [BendingBender](https://github.com/BendingBender).
