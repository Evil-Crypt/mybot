# Installation
> `npm install --save @types/json-buffer`

# Summary
This package contains type definitions for json-buffer (https://github.com/dominictarr/json-buffer).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/json-buffer

Additional Details
 * Last updated: Fri, 26 Jul 2019 18:14:43 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Paul Hawxby <https://github.com/phawxby>.
